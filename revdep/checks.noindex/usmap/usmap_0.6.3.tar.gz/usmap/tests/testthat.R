library(testthat)
library(usmap)

test_check("usmap")
